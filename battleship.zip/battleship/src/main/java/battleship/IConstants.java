package battleship;

public class IConstants {

	public static final int NO_OF_SHIPS = 5;
	public static final int GRID_ROW = 8;
	public static final int GRID_COL = 8;
	public static final int TOTAL_KILL_TO_WIN = 17;
	
	
}
