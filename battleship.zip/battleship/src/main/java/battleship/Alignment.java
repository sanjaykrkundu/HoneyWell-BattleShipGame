package battleship;

public enum Alignment {
	VERTICLE,HORIZONTAL
}
